create
    definer = root@localhost procedure listdept()
begin 
  select * from tb_dept;
end;

